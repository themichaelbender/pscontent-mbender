# Environment build for Installing and Running PowerShell labs

Author of Video Course: Jeff Hicks

Author of Labs: Michael Bender

Build Version: main-mark4.tf

## Update Log
- Remove unneeded EC2 instances from TF file
- Added function to disable server manager
- Remove RHEL and XRDP
- Install PSTeachingTools and PSReleaseTools from PS Gallery